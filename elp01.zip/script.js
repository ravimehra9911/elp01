const year = Date();

console.log(year);
